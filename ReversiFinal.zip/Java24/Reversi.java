import java.io.FileReader;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.util.Random;
import java.io.IOException;
/**
 * The game Reversi been designed for university project.
 * 
 * @author (Josh Ng) 
 * @version (v5)
 */
public class Reversi
{
    /**
     * creates a menu for the user to use and select option for them to play Reversi.
     */
    public static void main(String[] args){
        //clears screen.
        System.out.print("\u000C");
        //creates object of the game.
        Reversi game = new Reversi();
        //Asks user for choice from menu.
        int option = 0;
        System.out.println("1. Start New Game");
        System.out.println("2. Load Game");
        System.out.println("3. Quit");
        System.out.println("Enter your Choice");
        //Executes users choice.
        do{
            option = Genio.getInteger();

            if(option == 1){
                game.newGame();
            }
            else if(option == 2){
                game.loadGame();
            }
            else if(option == 3){
                System.exit(1);
            }
            else{
                System.out.println("Sorry that wasnt a option");
            }
        }while(option<1 || option>3);

    }

    /**
     * Starts a new game for the user and sets up the board.
     */
    public void newGame(){
        //Asks if user wouldlike to play against friend or computer.
        System.out.println("Press 1 for 1v1");
        System.out.println("Press 2 for computer");
        //declare variables
        int option;
        int opposite = 0;
        int player = 0;
        int[][] board = new int[8][8];
        //sets board to default numbers.
        for(int i = 0; i<board.length; i++){
            for(int j = 0; j<board[i].length; j++){
                board[i][j] = 0;
            }
        }
        //asks for users choice.
        do{
            option = Genio.getInteger();
            //sets board for player vs player.
            if(option == 1){
                player = 1;
                opposite = 2;
                board[3][3] = 1;
                board[4][4] = 1;
                board[3][4] = 2;
                board[4][3] = 2;
            }
            //sets board for player vs AI.
            else if(option == 2){
                player = 3;
                opposite = 4;
                board[3][3] = 3;
                board[4][4] = 3;
                board[3][4] = 4;
                board[4][3] = 4;
            }
            //If users presses wrong choice.
            else{
                System.out.println("Sorry thats not an option");
            }
        }while(option<1 || option >2);
        //starts game.
        playGame(board, player, opposite);
    }

    /**
     * Prints the board out.
     * 
     * A 2-D Array Board is passed into the method.
     */
    public void printTable(int[][] board){
        // prints Column-axis.
        System.out.println("0\t\t1\t\t2\t\t3\t\t4\t\t5\t\t6\t\t7\t\t8");
        //Prints Row-axis and board.
        for(int i = 0; i<board.length; i++){
            System.out.print(i+1 + "\t\t");
            for(int j = 0; j<board[i].length; j++){
                System.out.print(board[i][j] + "\t\t");
            }
            System.out.print("\r\n\r\n");
        }
    }

  

    /**
     * Prints the scores of both users.
     * 
     * A 2-D Array Board is passed into the method.
     */
    public void printScore(int[][]board){
        //sets players scores to zero.
        int player1Score = 0;
        int player2Score = 0;

        //adds all of the players counters.
        for(int i = 0; i<board.length; i++){
            for(int j = 0; j<board[i].length; j++){
                if(board[i][j] == 1 || board[i][j] == 3){
                    player1Score++;
                }
                else if(board[i][j] == 2 || board[i][j] == 4){
                    player2Score++;
                }
            }
        }
        //displays scores.
        System.out.println("Player 1 Score : " + player1Score + "\tPlayer 2 Score: " + player2Score);
    }

    /**
     * Starts the game from new game or load game.
     * 
     * A 2-D Array Board, integer player and opposite is passed into the method.
     */
    public void playGame(int[][] board, int player, int opposite){
        //sets variables to false.
        boolean finished = false;
        boolean noMove = false;

        //starts game.
        while(finished == false){ 
            //clears board and prints new board.
            System.out.print("\u000C");
            printTable(board);
            printScore(board);
            //gives players move.
            playerMove(board, player, opposite);
            //changes player and opposite peice.
            if(player == 1){
                player = 2;
                opposite = 1;
            }
            else if(player == 2){
                player = 1;
                opposite = 2;
            }
            else if(player == 3){
                player = 4;
                opposite = 3;
            }
            else if(player == 4){
                player = 3; 
                opposite = 4;
            }
            //checks if their are any available moves.
            noMove = checkAvailableMove(board, player, opposite);
            //if there are no moves.
            if(noMove != true){
                //change player.
                if(player == 1){
                    player = 2;
                    opposite = 1;
                    //stop the game.
                    if(checkAvailableMove(board, player, opposite) == false){
                        finished = true;
                    }
                }
                else if(player == 2){
                    player = 1;
                    opposite = 2;
                    if(checkAvailableMove(board, player, opposite) == false){
                        finished = true;
                    }
                }
                else if(player == 3){
                    player = 4;
                    opposite = 3;
                    if(checkAvailableMove(board, player, opposite) == false){
                        finished = true;
                    }
                }
                else if(player == 4){
                    player = 3;
                    opposite = 4;
                    if(checkAvailableMove(board, player, opposite) == false){
                        finished = true;
                    }
                }
            }
            //if board is full stop the game.
            if(fullBoard(board) != false){
                finished = true;
            } 
        }
        //finish the game print score and stop program.
        System.out.print("\u000C");
        printScore(board);
        System.out.println("thanks for playing");

    }

    /**
     * Gets player column and row location and if its valid move then counter is placed.
     * 
     * A 2-D Array Board, integer player and opposite is passed into the method.
     */
    public void playerMove(int[][] board, int player, int opposite){
        //create variables and object.
        Random rand = new Random();
        int column;
        int row;
        boolean help = false;
        boolean valid = false;
        //Does a while loop until the user has a valid move.
        while(valid == false){

            do{
                //Gets players col value.
                //If AI then get random integer.
                if(player == 4 || help == true){
                    column =  rand.nextInt(7);
                }
                else{
                    System.out.println("Player: " + player + " insert column co-ordinate type 100 to save");
                    System.out.println("press 10 if you need help (places counter for you)");
                    column = Genio.getInteger();
                    column--;
                    if(column == 99){
                        saveGame(board, player, opposite);
                        System.exit(1);
                    }
                    else if(column == 9){
                        help = true;
                    }
                   

                    if(column<0 || column>7 || column != 9){
                        System.out.print("\u000C");
                        printTable(board);
                        printScore(board);
                        System.out.println("Sorry thats not a co-ordinate");
                    }
                }
            }while(column<0 || column>7 || column == 10);
            do{
                if(player == 4 || help == true){
                    row = rand.nextInt(7);
                }
                else{
                    System.out.println("Player: " + player + " insert y co-ordinate");
                    row = Genio.getInteger();
                    row--;
                    if(row<0 || row>7){
                        System.out.print("\u000C");
                        printTable(board);
                        printScore(board);
                        System.out.println("Sorry thats not a co-ordinate");
                    }
                }
            }while(row<0 || row>7);
            valid = checkMove(board, row, column, player, opposite, 1);
            if(valid == false){
                System.out.print("\u000C");
                printTable(board);
                printScore(board);
                System.out.println("Sorry that isnt a correct move");
            }
        }
    }

    public boolean checkMove(int[][]board, int row, int column, int player, int opposite, int check){
        boolean[] valid = new boolean[8];
        boolean validMove = false;

        if(board[row][column] == 0){
            if(column<6){
                //checks right
                valid[0] = checkaAndMove(board, row, column, player, opposite, 0, 1, check);
            }
            if(column>1){
                //checks left
                valid[1] = checkaAndMove(board, row, column, player, opposite, 0, -1, check);
            }
            if(row>1){
                //check up
                valid[2] = checkaAndMove(board, row, column, player, opposite, -1, 0, check);
            }
            if(row<6){
                //checks down
                valid[3] = checkaAndMove(board, row, column, player, opposite, 1, 0, check);
            }
            if(row>1 && column<6){
                //checks up right
                valid[4] = checkaAndMove(board, row, column, player, opposite, -1, 1, check);
            }
            if(row<6 && column<6){
                //check down right
                valid[5] = checkaAndMove(board, row, column, player, opposite, 1, 1, check);
            }
            if(row>1 && column>1){
                //checks up left
                valid[6] = checkaAndMove(board, row, column, player, opposite, -1, -1, check);
            }
            if(row<6 && column>1){
                //checks down left
                valid[7] = checkaAndMove(board, row, column, player, opposite, 1, -1, check);
            }

            for(int i = 0; i<8; i++){
                if(valid[i] == true){
                    validMove = true;
                }
            }
        }
        return validMove;
    }

    public boolean checkaAndMove(int[][] board, int row, int column, int player, int opposite, int v, int h, int verify){
        boolean valid = false;

        if(board[row + v][column+h] != opposite){
        }
        else {
            int x = row + (v*2);
            int y = column + (h*2);
            boolean emptyGrid = false;
            boolean lineFormed = false;
            int columnIndex = 0;
            int rowIndex = 0;

            while(lineFormed == false && emptyGrid == false && y>=0 && y <8 && x>=0 && x<8){
                if(board[x][y] == 0){
                    emptyGrid = true;
                }
                else if(board[x][y] == player){
                    lineFormed = true;
                    columnIndex = y;
                    rowIndex = x;
                }
                else{
                    y = y + h;
                    x = x + v;
                }
            }
            if(lineFormed == true){
                if(verify == 1){
                    if(column <= columnIndex && row <= rowIndex){
                        for(int i = column, j = row; i<=columnIndex && j<=rowIndex; i= i + h, j = j + v){
                            board[j][i] = player;
                        }
                    }
                    else if(column >= columnIndex && row <= rowIndex){
                        for(int i = column, j = row; i>=columnIndex && j<=rowIndex; i= i + h, j = j + v){
                            board[j][i] = player;
                        }
                    }
                    else if(column <= columnIndex && row >= rowIndex){
                        for(int i = column, j = row; i<=columnIndex && j>=rowIndex; i= i + h, j = j + v){
                            board[j][i] = player;
                        }
                    }
                    else if(column >= columnIndex && row >= rowIndex){
                        for(int i = column, j = row; i>=columnIndex && j>=rowIndex; i= i + h, j = j + v){
                            board[j][i] = player;
                        }
                    }
                }
            }
            if(lineFormed == true){
                valid = true;
            }

        }
        return valid;

    }

    /**
     * Writes text to a file that the user has choosen.
     * If the text file does not exist a new file will be created.
     * The File will be in the same folder as the blueJ project.
     * 
     * Gets 2-D array board, player and opposites as integers in.
     */
    public void saveGame(int[][] board, int player, int opposite){
        //declares variables which will be used.
        FileOutputStream outputStream = null;
        PrintWriter printWriter = null;
        boolean continueWriting = true;
        int number;
        //Asks save file number.
        System.out.println("What file would you like to save it to 1, 2 or 3");
        do{
            number = Genio.getInteger();
            if(number<1 || number>3){
                System.out.println("Sorry thats not an option");
            }
        }while(number<1 || number>3);
        try
        {
            // creates a FileOutputStream object with a path.
            // to the file the user wants to use.
            outputStream = new FileOutputStream("SaveFile" + number +".txt");

            // creates a printWriter object and provides it with the FileOutPutStream.
            printWriter = new PrintWriter(outputStream);

            printWriter.println(player);
            printWriter.println(opposite);
            for(int i = 0; i<board.length; i++){
                for(int j = 0; j<board[i].length; j++){
                    printWriter.println(board[i][j]);
                }
            }
        }
        //if theres a error
        catch (IOException e)
        {
            //Tell user a error occured.
            System.out.println("Sorry theres a error opening or writing to this file");
        }
        finally
        {
            //If theres nothing in the printWriter.
            if (printWriter != null)
            {
                //Close the file
                printWriter.close();
            }
        }
    }

    /**
     * Loads a selected saved file for the user to continue their game.
     */
    public void loadGame(){
        //Declares Variables.
        int[][] board = new int[8][8];
        int player;
        int opposite;
        int number;
        String fileName;
        FileReader fileReader = null;
        BufferedReader bufferedReader = null;
        String nextLine;

        //Asks user for the file they would like to read
        System.out.println("What number is the file you would like to load 1, 2 or 3");
        do{
            number = Genio.getInteger();
            if(number<1 || number>3){
                System.out.println("Sorry thats not an option");
            }
        }while(number<1 || number>3);
        try
        {
            //Creates a FileReader object with the path of where the file the user wants to read.
            fileReader = new FileReader("SaveFile" + number +".txt");
            //Creates a BufferedReader object and provides it with the FileReader.
            bufferedReader = new BufferedReader(fileReader);

            //trys to read the first line in the file then saves it to the nextLine field.
            nextLine = bufferedReader.readLine();
            //sets first line to player.
            player = Integer.parseInt(nextLine);
            nextLine = bufferedReader.readLine();
            //sets second line to the opposite peice.
            opposite = Integer.parseInt(nextLine);

            //while the nextLine field isnt empty.
            //reads each line and sets it to the board.
            for(int i = 0; i<board.length; i++){
                for(int j = 0; j<board[i].length; j++){
                    nextLine = bufferedReader.readLine();
                    board[i][j] = Integer.parseInt(nextLine);
                }
            }
            //continues game.
            playGame(board, player, opposite);
        }
        //If theres a error
        catch(IOException e)
        {
            //Tell the user a error has occured.
            System.out.println("Sorry there has been an error in opening or reading the file.");
        }
        finally
        {
            // if the bufferReader is empty.
            if(bufferedReader != null)
            {
                //try closing the file.
                try 
                {
                    bufferedReader.close();
                }
                //if theres a error
                catch(IOException e)
                {
                    //Tell the user an error occured.
                    System.out.println("An error occurred when closing this file");
                }
            }
        }
    }
}

