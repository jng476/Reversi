package com.java24hours;

import javax.swing.*;
import java.awt.*;

public class ReversiMenu extends JFrame {
	public ReversiMenu() {
		super("Reversi");
		setLookAndFeel();
		setSize(920, 720);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		FlowLayout flo = new FlowLayout();
		setLayout(flo);
		JButton start = new JButton("Start");
		JButton load = new JButton("Load");
		JButton exit = new JButton("Exit");
		GridLayout layout = new GridLayout(5, 1, 10, 10);
		setLayout(layout);
		FlowLayout layout1 = new FlowLayout(FlowLayout.CENTER, 10, 10);
		
		add(start);
		add(load);
		add(exit);
		setVisible(true);
	}
	
	private void setLookAndFeel() {
		try {
			UIManager.setLookAndFeel (
				"com.sun.java.swing.plaf.numbus.NimbusLookAndFeel"
			);
		}	catch (Exception exc) {
				//ignore error
		}
	}
	
	public static void main(String[] args) {
		ReversiMenu frame = new ReversiMenu();
	}
}